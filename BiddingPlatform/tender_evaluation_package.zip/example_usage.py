﻿from tender_evaluator import TenderEvaluator
import asyncio
from fastapi import UploadFile
import os

async def evaluate_tenders(terms_pdf_path: str, proposal_pdf_paths: list[str], top_n: int = 3):
    # Initialize the evaluator
    evaluator = TenderEvaluator()
    
    # Create UploadFile objects from the PDF files
    terms = UploadFile(filename=os.path.basename(terms_pdf_path))
    terms.file = open(terms_pdf_path, 'rb')
    
    proposals = []
    for path in proposal_pdf_paths:
        proposal = UploadFile(filename=os.path.basename(path))
        proposal.file = open(path, 'rb')
        proposals.append(proposal)
    
    try:
        # Evaluate the tenders
        result = await evaluator.evaluate_tender(terms, proposals, top_n)
        return result
    finally:
        # Clean up file handles
        terms.file.close()
        for proposal in proposals:
            proposal.file.close()

# Example usage
async def main():
    terms_path = 'path/to/your/terms.pdf'
    proposal_paths = [
        'path/to/proposal1.pdf',
        'path/to/proposal2.pdf',
        'path/to/proposal3.pdf'
    ]
    
    result = await evaluate_tenders(terms_path, proposal_paths, top_n=2)
    print(result)

if __name__ == '__main__':
    asyncio.run(main())
